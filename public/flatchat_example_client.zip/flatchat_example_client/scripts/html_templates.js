function errorsHtml(errors) {
  return ' \
  <div class="alert alert-warning alert-dismissible"> \
    <button class="close" data-dismiss="alert"> \
      <span>×</span> \
    </button>' +
    errors.join('<br>') +
  '</div>';
};

function roomHtml(room) {
  return ' \
  <div id="room_' + room.id + '" class="room" data-room-id="' + room.id + '"> \
    <div class="username">' + room.user + '</div> \
    <time class="timeago" datetime="' + room.created_at + '">' + room.created_at + '</time> \
    <div class="room_name"><i class="fa fa-comments-o"></i> ' + room.name + '</div> \
  </div>';
};

function messageHtml(message) {
  return ' \
  <div id="message_' + message.id + '" class="message"> \
    <div class="username">' + message.user + '</div> \
    <time class="timeago" datetime="' + message.created_at + '">' + message.created_at + '</time> \
    <div class="message_body"> \
      <i class="fa fa-comment-o"></i> ' + message.body + ' \
    </div> \
  </div>';
};

function roomNameHtml(room) {
  return '<i class="fa fa-comments-o"></i> ' + room.name;
};
