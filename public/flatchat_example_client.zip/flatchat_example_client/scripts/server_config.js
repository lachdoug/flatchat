serverUrl = "";
serverWebSocketUrl = "";
apiToken = "";
