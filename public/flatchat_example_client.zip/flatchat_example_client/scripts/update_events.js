$( document ).ready(function() {

  webSocketConnection = new WebSocket(serverWebSocketUrl + '?token=' + apiToken);

  webSocketConnection.onopen = function(serverEvent) {
    webSocketConnection.send(
      JSON.stringify(
        { "command": "subscribe",
          "identifier": JSON.stringify({"channel":"EventsChannel"})
        })
    );
  };

  webSocketConnection.onmessage = function(serverEvent) {
    processEvent(serverEvent);
  };

});

var processEvent = function(serverEvent) {
  var eventData = JSON.parse(serverEvent.data);
  if (eventData.identifier !== undefined) {
    var eventMessage = eventData.message;
    if (eventMessage !== undefined) {
      var eventType = eventMessage.event;
      if (eventType === "new_room") { addRoom(eventMessage) };
      if (eventType === "new_message") { addMessage(eventMessage) };
    };
  };
};

var addRoom = function(eventMessage) {
  $('#rooms').prepend(roomHtml(JSON.parse(eventMessage.room)));
  $('#rooms').children().first().click();
  $('#input_room_name').val('');
  bindTimeago();
};

var addMessage = function(eventMessage) {
  var updateRoomId = JSON.parse(eventMessage.message).room_id.toString();
  var selectedRoomId = $("#input_message_room_id").val();
  if ( updateRoomId === selectedRoomId) {
    $("#messages").prepend(messageHtml(JSON.parse(eventMessage.message)));
    $('#input_message_body').val('');
    bindTimeago();
  };
};
