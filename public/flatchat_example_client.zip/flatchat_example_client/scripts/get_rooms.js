var loadRooms = function() {
  $.get(serverUrl + "/rooms.json", function(rooms) {
    $.each(rooms, function(index, room){
      $('#rooms').append(roomHtml(room));
    });
    bindTimeago();
  });
};

$( document ).ready(function() {
  loadRooms();
});
