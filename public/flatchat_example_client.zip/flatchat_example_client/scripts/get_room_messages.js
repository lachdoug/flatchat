var bindLoadRoomOnListClick = function() {
  $("#rooms").on("click", ".room", function(event){
    var roomId = $(this).data("room-id");
    $.get((serverUrl + "/rooms/" + roomId + ".json"), function(room) {
      $("#messages_panel").hide();
      $("#messages").empty();
      $.each(room.messages, function(index, message) {
        $("#messages").prepend(messageHtml(message));
      });
      bindTimeago();
      $("#selected_room_name").html(roomNameHtml(room));
      $("#input_message_body").val('');
      $("#input_message_room_id").val(room.id);
      $("#messages_panel").fadeIn();
    });
  });
};

$( document ).ready(function() {
  bindLoadRoomOnListClick();
});
