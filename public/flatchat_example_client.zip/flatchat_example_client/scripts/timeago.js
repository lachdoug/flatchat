function bindTimeago() {
  jQuery("time.timeago").timeago();
};
