$( document ).ready(function() {
  document.new_room_form.action = ( serverUrl + "/rooms.json" );
  document.new_message_form.action = ( serverUrl + "/messages.json" );
});
