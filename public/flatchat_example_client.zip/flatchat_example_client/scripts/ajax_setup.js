var bindAjaxForm = function() {
  $('form').ajaxForm({
    error: function(request, textStatus, errorThrown, form) {
      var errors = JSON.parse(request.responseText).errors;
      form.next().html(errorsHtml(errors));
    }
  });
};

$.ajaxSetup({
  headers: { 'Authorization' : 'Token ' + apiToken },
  dataType: "json"
});

$(document).ready(function() {
  bindAjaxForm();
});
